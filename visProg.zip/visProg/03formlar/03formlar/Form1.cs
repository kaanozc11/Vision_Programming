namespace _03formlar
{
    public partial class Form1 : Form
    {
        private string copiedContent1;
        private string copiedContent2;
        private int kopyalananKarakterSayisi;
        public Form1()
        {
            InitializeComponent();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void kesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip3_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void tümünüSeçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox2.SelectAll();
        }

        private void kopyalaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox1.Copy();
            kopyalananKarakterSayisi = textBox1.Text.Length;
            toolStripStatusLabel4.Text = kopyalananKarakterSayisi.ToString();
        }

        private void yapıştırToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
        }

        private void açToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void açToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripProgressBar2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void kadın_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void kadın_MouseEnter(object sender, EventArgs e)
        {
            // if (this.radioButton1.Checked)
            //   [radioButton1.Checked = false;]
        }

        private void kadın_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
                progressBar1.Value = progressBar1.Value + 10;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
        }
    }
}
