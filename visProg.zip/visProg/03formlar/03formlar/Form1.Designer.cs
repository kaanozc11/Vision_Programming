﻿namespace _03formlar
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            contextMenuStrip1 = new ContextMenuStrip(components);
            kopyalaToolStripMenuItem1 = new ToolStripMenuItem();
            yapıştırToolStripMenuItem1 = new ToolStripMenuItem();
            yeniToolStripMenuItem1 = new ToolStripMenuItem();
            dosyaToolStripMenuItem = new ToolStripMenuItem();
            klasörToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripMenuItem();
            textBox1 = new TextBox();
            contextMenuStrip2 = new ContextMenuStrip(components);
            kopyalaToolStripMenuItem = new ToolStripMenuItem();
            yapıştırToolStripMenuItem = new ToolStripMenuItem();
            yeniToolStripMenuItem = new ToolStripMenuItem();
            textBox2 = new TextBox();
            contextMenuStrip3 = new ContextMenuStrip(components);
            kopyalaToolStripMenuItem2 = new ToolStripMenuItem();
            yapıştırToolStripMenuItem2 = new ToolStripMenuItem();
            tümünüSeçToolStripMenuItem = new ToolStripMenuItem();
            yeniToolStripMenuItem2 = new ToolStripMenuItem();
            dosyaToolStripMenuItem1 = new ToolStripMenuItem();
            klasörToolStripMenuItem1 = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            menuStrip1 = new MenuStrip();
            dosyaToolStripMenuItem2 = new ToolStripMenuItem();
            açToolStripMenuItem1 = new ToolStripMenuItem();
            kaydetToolStripMenuItem = new ToolStripMenuItem();
            açToolStripMenuItem = new ToolStripMenuItem();
            openFileDialog1 = new OpenFileDialog();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            toolStripStatusLabel3 = new ToolStripStatusLabel();
            toolStripStatusLabel2 = new ToolStripStatusLabel();
            toolStripStatusLabel4 = new ToolStripStatusLabel();
            toolStripProgressBar1 = new ToolStripProgressBar();
            panel1 = new Panel();
            groupBox2 = new GroupBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            groupBox1 = new GroupBox();
            kadın = new RadioButton();
            erkek = new RadioButton();
            splitContainer1 = new SplitContainer();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            progressBar1 = new ProgressBar();
            button2 = new Button();
            button1 = new Button();
            contextMenuStrip1.SuspendLayout();
            contextMenuStrip2.SuspendLayout();
            contextMenuStrip3.SuspendLayout();
            menuStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            panel1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { kopyalaToolStripMenuItem1, yapıştırToolStripMenuItem1, yeniToolStripMenuItem1, toolStripMenuItem1 });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(180, 92);
            contextMenuStrip1.Opening += contextMenuStrip1_Opening;
            // 
            // kopyalaToolStripMenuItem1
            // 
            kopyalaToolStripMenuItem1.Checked = true;
            kopyalaToolStripMenuItem1.CheckState = CheckState.Checked;
            kopyalaToolStripMenuItem1.Name = "kopyalaToolStripMenuItem1";
            kopyalaToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.C;
            kopyalaToolStripMenuItem1.Size = new Size(179, 22);
            kopyalaToolStripMenuItem1.Text = "kopyala";
            kopyalaToolStripMenuItem1.ToolTipText = "kopyalar";
            kopyalaToolStripMenuItem1.Click += kopyalaToolStripMenuItem1_Click;
            // 
            // yapıştırToolStripMenuItem1
            // 
            yapıştırToolStripMenuItem1.Name = "yapıştırToolStripMenuItem1";
            yapıştırToolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.V;
            yapıştırToolStripMenuItem1.Size = new Size(179, 22);
            yapıştırToolStripMenuItem1.Text = "yapıştır";
            // 
            // yeniToolStripMenuItem1
            // 
            yeniToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { dosyaToolStripMenuItem, klasörToolStripMenuItem });
            yeniToolStripMenuItem1.Name = "yeniToolStripMenuItem1";
            yeniToolStripMenuItem1.Size = new Size(179, 22);
            yeniToolStripMenuItem1.Text = "yeni";
            // 
            // dosyaToolStripMenuItem
            // 
            dosyaToolStripMenuItem.Name = "dosyaToolStripMenuItem";
            dosyaToolStripMenuItem.Size = new Size(105, 22);
            dosyaToolStripMenuItem.Text = "dosya";
            // 
            // klasörToolStripMenuItem
            // 
            klasörToolStripMenuItem.Name = "klasörToolStripMenuItem";
            klasörToolStripMenuItem.Size = new Size(105, 22);
            klasörToolStripMenuItem.Text = "klasör";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.ShortcutKeys = Keys.Control | Keys.A;
            toolStripMenuItem1.Size = new Size(179, 22);
            toolStripMenuItem1.Text = "tümünü seç";
            // 
            // textBox1
            // 
            textBox1.ContextMenuStrip = contextMenuStrip1;
            textBox1.Location = new Point(40, 25);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(204, 23);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { kopyalaToolStripMenuItem, yapıştırToolStripMenuItem, yeniToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip1";
            contextMenuStrip2.Size = new Size(116, 70);
            // 
            // kopyalaToolStripMenuItem
            // 
            kopyalaToolStripMenuItem.Name = "kopyalaToolStripMenuItem";
            kopyalaToolStripMenuItem.Size = new Size(115, 22);
            kopyalaToolStripMenuItem.Text = "kopyala";
            // 
            // yapıştırToolStripMenuItem
            // 
            yapıştırToolStripMenuItem.Name = "yapıştırToolStripMenuItem";
            yapıştırToolStripMenuItem.Size = new Size(115, 22);
            yapıştırToolStripMenuItem.Text = "yapıştır";
            // 
            // yeniToolStripMenuItem
            // 
            yeniToolStripMenuItem.Name = "yeniToolStripMenuItem";
            yeniToolStripMenuItem.Size = new Size(115, 22);
            yeniToolStripMenuItem.Text = "yeni";
            // 
            // textBox2
            // 
            textBox2.ContextMenuStrip = contextMenuStrip3;
            textBox2.Location = new Point(40, 54);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(204, 23);
            textBox2.TabIndex = 2;
            // 
            // contextMenuStrip3
            // 
            contextMenuStrip3.Items.AddRange(new ToolStripItem[] { kopyalaToolStripMenuItem2, yapıştırToolStripMenuItem2, tümünüSeçToolStripMenuItem, yeniToolStripMenuItem2 });
            contextMenuStrip3.Name = "contextMenuStrip3";
            contextMenuStrip3.Size = new Size(180, 92);
            contextMenuStrip3.Opening += contextMenuStrip3_Opening;
            // 
            // kopyalaToolStripMenuItem2
            // 
            kopyalaToolStripMenuItem2.Name = "kopyalaToolStripMenuItem2";
            kopyalaToolStripMenuItem2.ShortcutKeys = Keys.Control | Keys.C;
            kopyalaToolStripMenuItem2.Size = new Size(179, 22);
            kopyalaToolStripMenuItem2.Text = "kopyala";
            // 
            // yapıştırToolStripMenuItem2
            // 
            yapıştırToolStripMenuItem2.Name = "yapıştırToolStripMenuItem2";
            yapıştırToolStripMenuItem2.ShortcutKeys = Keys.Control | Keys.V;
            yapıştırToolStripMenuItem2.Size = new Size(179, 22);
            yapıştırToolStripMenuItem2.Text = "yapıştır";
            yapıştırToolStripMenuItem2.Click += yapıştırToolStripMenuItem2_Click;
            // 
            // tümünüSeçToolStripMenuItem
            // 
            tümünüSeçToolStripMenuItem.Name = "tümünüSeçToolStripMenuItem";
            tümünüSeçToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.A;
            tümünüSeçToolStripMenuItem.Size = new Size(179, 22);
            tümünüSeçToolStripMenuItem.Text = "tümünü seç";
            tümünüSeçToolStripMenuItem.Click += tümünüSeçToolStripMenuItem_Click;
            // 
            // yeniToolStripMenuItem2
            // 
            yeniToolStripMenuItem2.DropDownItems.AddRange(new ToolStripItem[] { dosyaToolStripMenuItem1, klasörToolStripMenuItem1 });
            yeniToolStripMenuItem2.Name = "yeniToolStripMenuItem2";
            yeniToolStripMenuItem2.Size = new Size(179, 22);
            yeniToolStripMenuItem2.Text = "yeni";
            // 
            // dosyaToolStripMenuItem1
            // 
            dosyaToolStripMenuItem1.Name = "dosyaToolStripMenuItem1";
            dosyaToolStripMenuItem1.Size = new Size(105, 22);
            dosyaToolStripMenuItem1.Text = "dosya";
            // 
            // klasörToolStripMenuItem1
            // 
            klasörToolStripMenuItem1.Name = "klasörToolStripMenuItem1";
            klasörToolStripMenuItem1.Size = new Size(105, 22);
            klasörToolStripMenuItem1.Text = "klasör";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-4, 28);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 3;
            label1.Text = "kaynak";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(-3, 57);
            label2.Name = "label2";
            label2.Size = new Size(37, 15);
            label2.TabIndex = 4;
            label2.Text = "hedef";
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { dosyaToolStripMenuItem2, açToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 5;
            menuStrip1.Text = "menuStrip1";
            // 
            // dosyaToolStripMenuItem2
            // 
            dosyaToolStripMenuItem2.DropDownItems.AddRange(new ToolStripItem[] { açToolStripMenuItem1, kaydetToolStripMenuItem });
            dosyaToolStripMenuItem2.Name = "dosyaToolStripMenuItem2";
            dosyaToolStripMenuItem2.Size = new Size(50, 20);
            dosyaToolStripMenuItem2.Text = "dosya";
            // 
            // açToolStripMenuItem1
            // 
            açToolStripMenuItem1.Name = "açToolStripMenuItem1";
            açToolStripMenuItem1.Size = new Size(109, 22);
            açToolStripMenuItem1.Text = "aç";
            açToolStripMenuItem1.Click += açToolStripMenuItem1_Click;
            // 
            // kaydetToolStripMenuItem
            // 
            kaydetToolStripMenuItem.Name = "kaydetToolStripMenuItem";
            kaydetToolStripMenuItem.Size = new Size(109, 22);
            kaydetToolStripMenuItem.Text = "kaydet";
            // 
            // açToolStripMenuItem
            // 
            açToolStripMenuItem.Name = "açToolStripMenuItem";
            açToolStripMenuItem.Size = new Size(31, 20);
            açToolStripMenuItem.Text = "aç";
            açToolStripMenuItem.Click += açToolStripMenuItem_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1, toolStripStatusLabel3, toolStripStatusLabel2, toolStripStatusLabel4, toolStripProgressBar1 });
            statusStrip1.Location = new Point(0, 428);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(800, 22);
            statusStrip1.TabIndex = 6;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(43, 17);
            toolStripStatusLabel1.Text = "durum";
            toolStripStatusLabel1.Click += toolStripStatusLabel1_Click;
            // 
            // toolStripStatusLabel3
            // 
            toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            toolStripStatusLabel3.Size = new Size(30, 17);
            toolStripStatusLabel3.Text = "aktif";
            // 
            // toolStripStatusLabel2
            // 
            toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            toolStripStatusLabel2.Size = new Size(144, 17);
            toolStripStatusLabel2.Text = "kopyalanan karakter sayısı";
            // 
            // toolStripStatusLabel4
            // 
            toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            toolStripStatusLabel4.Size = new Size(13, 17);
            toolStripStatusLabel4.Text = "0";
            // 
            // toolStripProgressBar1
            // 
            toolStripProgressBar1.Name = "toolStripProgressBar1";
            toolStripProgressBar1.Size = new Size(100, 16);
            toolStripProgressBar1.Value = 75;
            // 
            // panel1
            // 
            panel1.Controls.Add(groupBox2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(411, 194);
            panel1.TabIndex = 8;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Location = new Point(211, 83);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(197, 100);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "miktar";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(74, 36);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(36, 19);
            radioButton1.TabIndex = 9;
            radioButton1.TabStop = true;
            radioButton1.Text = "az";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(74, 61);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(44, 19);
            radioButton2.TabIndex = 10;
            radioButton2.TabStop = true;
            radioButton2.Text = "çok";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(kadın);
            groupBox1.Controls.Add(erkek);
            groupBox1.Location = new Point(5, 83);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(197, 100);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "cinsiyet";
            // 
            // kadın
            // 
            kadın.AutoSize = true;
            kadın.Location = new Point(6, 37);
            kadın.Name = "kadın";
            kadın.Size = new Size(54, 19);
            kadın.TabIndex = 0;
            kadın.TabStop = true;
            kadın.Text = "kadın";
            kadın.UseVisualStyleBackColor = true;
            kadın.CheckedChanged += kadın_CheckedChanged;
            kadın.KeyPress += kadın_KeyPress;
            kadın.MouseEnter += kadın_MouseEnter;
            // 
            // erkek
            // 
            erkek.AutoSize = true;
            erkek.Location = new Point(7, 62);
            erkek.Name = "erkek";
            erkek.Size = new Size(53, 19);
            erkek.TabIndex = 1;
            erkek.TabStop = true;
            erkek.Text = "erkek";
            erkek.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            splitContainer1.Location = new Point(32, 28);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(panel1);
            splitContainer1.Size = new Size(679, 200);
            splitContainer1.SplitterDistance = 417;
            splitContainer1.TabIndex = 9;
            splitContainer1.SplitterMoved += splitContainer1_SplitterMoved;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(12, 27);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(776, 353);
            tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(splitContainer1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(768, 325);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "kişisel";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(progressBar1);
            tabPage2.Controls.Add(button2);
            tabPage2.Controls.Add(button1);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(768, 325);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "kurumsal";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(57, 141);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(156, 23);
            progressBar1.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(138, 117);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 1;
            button2.Text = "10 arttır";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(57, 117);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "sıfırla";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Controls.Add(statusStrip1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            contextMenuStrip1.ResumeLayout(false);
            contextMenuStrip2.ResumeLayout(false);
            contextMenuStrip3.ResumeLayout(false);
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ContextMenuStrip contextMenuStrip1;
        private TextBox textBox1;
        private ToolStripMenuItem kopyalaToolStripMenuItem1;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem kopyalaToolStripMenuItem;
        private ToolStripMenuItem yapıştırToolStripMenuItem;
        private ToolStripMenuItem yeniToolStripMenuItem;
        private ToolStripMenuItem yapıştırToolStripMenuItem1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private ContextMenuStrip contextMenuStrip3;
        private ToolStripMenuItem kopyalaToolStripMenuItem2;
        private ToolStripMenuItem yapıştırToolStripMenuItem2;
        private ToolStripMenuItem yeniToolStripMenuItem1;
        private ToolStripMenuItem dosyaToolStripMenuItem;
        private ToolStripMenuItem klasörToolStripMenuItem;
        private ToolStripMenuItem tümünüSeçToolStripMenuItem;
        private ToolStripMenuItem yeniToolStripMenuItem2;
        private ToolStripMenuItem dosyaToolStripMenuItem1;
        private ToolStripMenuItem klasörToolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem dosyaToolStripMenuItem2;
        private ToolStripMenuItem açToolStripMenuItem;
        private ToolStripMenuItem açToolStripMenuItem1;
        private ToolStripMenuItem kaydetToolStripMenuItem;
        private OpenFileDialog openFileDialog1;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ToolStripStatusLabel toolStripStatusLabel3;
        private ToolStripStatusLabel toolStripStatusLabel2;
        private ToolStripStatusLabel toolStripStatusLabel4;
        private ToolStripProgressBar toolStripProgressBar1;
        private Panel panel1;
        private RadioButton kadın;
        private RadioButton erkek;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private SplitContainer splitContainer1;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private ProgressBar progressBar1;
        private Button button2;
        private Button button1;
    }
}
