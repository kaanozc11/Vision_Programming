namespace DateTimePicker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime zaman = dateTimePicker1.Value;
            textBox1.Text = zaman.ToString();
            textBox2.Text = zaman.Date.ToString();
            textBox3.Text = zaman.TimeOfDay.ToString();
            textBox4.Text = zaman.Year.ToString();
            textBox5.Text = zaman.ToString("MMMM");
            textBox6.Text = zaman.Month.ToString();
            textBox7.Text = zaman.ToString("dddd");
            textBox8.Text = zaman.Day.ToString();
            textBox9.Text = zaman.DayOfYear.ToString();
            textBox11.Text = zaman.Minute.ToString();
            textBox12.Text = zaman.Second.ToString();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value <= numericUpDown1.Minimum)
            {
                MessageBox.Show("minimumdan daha küçük değer alamaz.");
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            maskedTextBox1.Mask = "#00 (000) 000 00 00- 99999";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] musteri = new string[2];
            musteri[0] = textBox10.Text;
            musteri[1] = textBox13.Text;

            ListViewItem kayit;
            kayit = new ListViewItem(musteri);
            listView1.Items.Add(kayit);
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Columns.Add("isim", 250);
            listView1.Columns.Add("soyisim", 250);
            listView1.Width = 650;
        }

        
    }
}
