namespace _01formOlayları
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            label3_MouseHover(sender, e);

            // label1.Text = "Güz Yıldız";

            // label1.Size = new Size(190, 47);

            DateTime saat = DateTime.Now;
            if (saat.Hour < 12)
            {
                label1.Text = "Günaydın";
            }
            else if (saat.Hour > 12 && saat.Hour < 18)
            {
                label1.Text = "Tünaydın";
            }
            else if (saat.Hour > 18)
            {
                label1.Text = "İyi Akşamlar";
            }

            label2.Text = saat.ToString();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void label3_MouseHover(object sender, EventArgs e)
        {
            label3.Text = "Güz";
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.Text = "Yıldız";
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            label2.Text = e.KeyChar.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            //this.Close();
            //this.Dispose(); 

            // textBox1.Text = label3.Text;
            Form2 frm2 = new Form2();
            frm2.ShowDialog();


        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //label4.Text = textBox1.Text.Length.ToString();
            String kismiicerik = textBox1.Select(15);
        }
    }
}
