using System.Data;

namespace hafta4

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void armutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Console.WriteLine("Selam");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void elmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.SelectAll();




        }

        private void kopyalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Copy();
            toolStripStatusLabel3.Text = textBox1.SelectedText.Length.ToString();
        }

        private void yapıştırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Paste();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip2_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void yapıştırToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            textBox2.Paste();





        }

        private void kopyalaToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void anaSayfaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void açToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

            toolStripStatusLabel2.Text = textBox1.Text.Length.ToString();
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                rb.Checked = false;
            }
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                rb.Checked = false;
            }
        }

        private void radioButton3_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                rb.Checked = false;
            }
        }

        private void radioButton4_Click(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb != null && rb.Checked)
            {
                rb.Checked = false;
            }
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (progressBar1.Value + 10 <= 100)
            {
                progressBar1.Value += 10;
            }
            else
            {
                progressBar1.Value = 100;
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("İsim", typeof(string));
            dt.Columns.Add("Bölüm", typeof(string));
            dt.Columns.Add("Doğum Tarihi", typeof(DateTime));

            dt.PrimaryKey = new DataColumn[] { dt.Columns["ID"] };

            dt.Rows.Add(1, "Ahmet", "Sosyoloji", new DateTime(1990, 5, 15));
            dt.Rows.Add(2, "Zeynep", "Coğrafya", new DateTime(1992, 8, 20));
            dt.Rows.Add(3, "Elif", "Matematik", new DateTime(1988, 12, 10));

            Console.WriteLine("İlk satırının bölümü: {0} " + dt.Rows[0]["Bölüm"]);
            for (int i = 1; i < dt.Rows.Count; i++)
            {
                Console.WriteLine("ID: {0}, İsim: {1}, Bölüm: {2}, Doğum Tarihi: {3}",
                    dt.Rows[i]["ID"], dt.Rows[i]["İsim"], dt.Rows[i]["Bölüm"], dt.Rows[i]["Doğum Tarihi"]);
            }
            dataGridView1.DataSource = dt;



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Seçili satırın geçerli olup olmadığını kontrol et
            if (e.RowIndex >= 0)
            {
                // Tıklanan satırı al
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Hücrelerdeki verileri Textbox'lara yazdır
                // ToString() metodu veriyi string'e (yazıya) çevirir
                textBox3.Text = row.Cells["ID"].Value.ToString();
                textBox4.Text = row.Cells["İsim"].Value.ToString();
                textBox5.Text = row.Cells["Bölüm"].Value.ToString();

                // Tarih formatını sadece gün.ay.yıl olarak göstermek için ToString kullanıyoruz
                // Örneğin: 15.05.1990

                textBox6.Text = Convert.ToDateTime(row.Cells["Doğum Tarihi"].Value).ToShortDateString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // DataGridView'in bağlı olduğu veri tablosunu (DataTable) al
            DataTable dt = (DataTable)dataGridView1.DataSource;

            // Eğer tablo bulunduysa ekleme yap
            if (dt != null)
            {
                try
                {
                    // Textbox'taki yazıları uygun veri tiplerine çevir
                    int id = Convert.ToInt32(textBox3.Text); // Yazıyı sayıya çevir
                    string isim = textBox4.Text;
                    string bolum = textBox5.Text;
                    DateTime dogumTarihi = Convert.ToDateTime(textBox6.Text); // Yazıyı tarihe çevir

                    // Tabloya yeni satır olarak ekle
                    dt.Rows.Add(id, isim, bolum, dogumTarihi);
                }
                catch (Exception hata)
                {
                    // Eğer kullanıcı yanlış bir veri girerse (örneğin ID yerine harf) mesaj göster
                    MessageBox.Show("Veri eklenemedi! ID için sayı, Tarih için doğru format (gg.aa.yyyy) giriniz.");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Seçili bir satır varsa ve yeni (boş) bir satır değilse güncelle
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.IsNewRow == false)
            {
                try
                {
                    // Seçili satırı al
                    DataGridViewRow row = dataGridView1.CurrentRow;

                    // Textbox'lardaki yeni verilerle hücreleri güncelle
                    row.Cells["ID"].Value = Convert.ToInt32(textBox3.Text);
                    row.Cells["İsim"].Value = textBox4.Text;
                    row.Cells["Bölüm"].Value = textBox5.Text;
                    row.Cells["Doğum Tarihi"].Value = Convert.ToDateTime(textBox6.Text);
                }
                catch (Exception hata)
                {
                    // Eğer bilgiler yanlış formatta girilmişse hata mesajı ver
                    MessageBox.Show("Veri güncellenemedi! Girdiğiniz bilgileri kontrol edin.");
                }
            }
            else
            {
                MessageBox.Show("Lütfen güncellemek için listeden bir kayıt seçin.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Seçili bir satır varsa ve yeni (boş) bir satır değilse sil
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.IsNewRow == false)
            {
                // Seçili satırı tablodan kaldır
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);

                // Textbox'ların içini temizle (boşalt)
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
            }
            else
            {
                MessageBox.Show("Lütfen silmek için listeden bir kayıt seçin.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

