namespace _02formComponents
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cinsiyet = "";
            if (radioButton1.Checked == true)
            {
                cinsiyet = radioButton1.Text;
                // MessageBox.Show(radioButton1.Text);
            }
            else if (radioButton2.Checked == true)
            {
                cinsiyet = radioButton2.Text;
                // MessageBox.Show(radioButton2.Text);
            }
            else if (radioButton3.Checked == true)
            {
                cinsiyet = radioButton3.Text;
                // MessageBox.Show(radioButton3.Text);
            }

            string bolum = comboBox1.SelectedItem.ToString();
            // MessageBox.Show(bolum);

            string isim = textBox1.Text;
            string soyisim = textBox2.Text;

            string adres = textBox3.Text;

            string liste_satiri = isim + " " + soyisim + " " + adres + " " + cinsiyet + " " + bolum;
            listBox1.Items.Add(liste_satiri);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int seciliSatir = listBox1.SelectedIndex;
            listBox1.Items.RemoveAt(seciliSatir);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();

            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;

            comboBox1.SelectedIndex = -1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.SelectionMode = SelectionMode.MultiSimple;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string secili = "";
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i))
                {
                    secili += (String)checkedListBox1.Items[i] + ", ";
                }
            }
            MessageBox.Show(secili);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            foreach (Control item in this.Controls)
            {
                if (item is CheckBox)
                {
                    CheckBox cb = (CheckBox)item;
                    if (cb.Checked)
                    {
                        listBox1.Items.Add(cb.Text);
                    }
                }
            }
        }
    }
}
