﻿namespace _02formComponents
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            checkBox1 = new CheckBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            label4 = new Label();
            checkBox2 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            label5 = new Label();
            textBox3 = new TextBox();
            listBox1 = new ListBox();
            button1 = new Button();
            comboBox1 = new ComboBox();
            label6 = new Label();
            button2 = new Button();
            button3 = new Button();
            checkedListBox1 = new CheckedListBox();
            button4 = new Button();
            button5 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(36, 28);
            label1.Name = "label1";
            label1.Size = new Size(29, 15);
            label1.TabIndex = 0;
            label1.Text = "isim";
            label1.Click += label1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(71, 25);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(172, 23);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(71, 54);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(172, 23);
            textBox2.TabIndex = 3;
            textBox2.Text = " ";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 57);
            label2.Name = "label2";
            label2.Size = new Size(47, 15);
            label2.TabIndex = 2;
            label2.Text = "soyisim";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 107);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 4;
            label3.Text = "cinsiyet";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(84, 141);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(61, 19);
            checkBox1.TabIndex = 5;
            checkBox1.Text = "yüzme";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(72, 107);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(54, 19);
            radioButton1.TabIndex = 6;
            radioButton1.TabStop = true;
            radioButton1.Text = "kadın";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(132, 105);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(53, 19);
            radioButton2.TabIndex = 7;
            radioButton2.TabStop = true;
            radioButton2.Text = "erkek";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(191, 105);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(52, 19);
            radioButton3.TabIndex = 8;
            radioButton3.TabStop = true;
            radioButton3.Text = "diğer";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 147);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 9;
            label4.Text = "hobiler";
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(176, 143);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(64, 19);
            checkBox2.TabIndex = 10;
            checkBox2.Text = "satranç";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(176, 168);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(66, 19);
            checkBox5.TabIndex = 13;
            checkBox5.Text = "seyahat";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(84, 166);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(68, 19);
            checkBox6.TabIndex = 12;
            checkBox6.Text = "yürüyüş";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(30, 204);
            label5.Name = "label5";
            label5.Size = new Size(35, 15);
            label5.TabIndex = 14;
            label5.Text = "adres";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(71, 204);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(171, 139);
            textBox3.TabIndex = 15;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(266, 25);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(217, 364);
            listBox1.TabIndex = 16;
            // 
            // button1
            // 
            button1.Location = new Point(37, 392);
            button1.Name = "button1";
            button1.Size = new Size(206, 31);
            button1.TabIndex = 17;
            button1.Text = "kaydet";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "YBS", "İktisat", "İşletme", "Ekonomi", "Turizm", "ÇEKO" });
            comboBox1.Location = new Point(73, 349);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(170, 23);
            comboBox1.TabIndex = 18;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(24, 352);
            label6.Name = "label6";
            label6.Size = new Size(42, 15);
            label6.TabIndex = 19;
            label6.Text = "bölüm";
            label6.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(38, 429);
            button2.Name = "button2";
            button2.Size = new Size(205, 31);
            button2.TabIndex = 21;
            button2.Text = "satır sil";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(38, 466);
            button3.Name = "button3";
            button3.Size = new Size(205, 31);
            button3.TabIndex = 22;
            button3.Text = "hepsini sil";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // checkedListBox1
            // 
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Items.AddRange(new object[] { "omg", "wow", "ooo" });
            checkedListBox1.Location = new Point(266, 403);
            checkedListBox1.Name = "checkedListBox1";
            checkedListBox1.Size = new Size(217, 94);
            checkedListBox1.TabIndex = 23;
            // 
            // button4
            // 
            button4.Location = new Point(489, 474);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 24;
            button4.Text = "göster";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(12, 162);
            button5.Name = "button5";
            button5.Size = new Size(63, 23);
            button5.TabIndex = 25;
            button5.Text = "h kaydet";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(678, 511);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(checkedListBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label6);
            Controls.Add(comboBox1);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Controls.Add(textBox3);
            Controls.Add(label5);
            Controls.Add(checkBox5);
            Controls.Add(checkBox6);
            Controls.Add(checkBox2);
            Controls.Add(label4);
            Controls.Add(radioButton3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(checkBox1);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private CheckBox checkBox1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private Label label4;
        private CheckBox checkBox2;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private Label label5;
        private TextBox textBox3;
        private ListBox listBox1;
        private Button button1;
        private ComboBox comboBox1;
        private Label label6;
        private Button button2;
        private Button button3;
        private CheckedListBox checkedListBox1;
        private Button button4;
        private Button button5;
    }
}
